import telegram
from telegram.ext import Updater, CommandHandler
import logging

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

# Replace with your bot token
TOKEN = "7689084982:AAGH5H1X7yJYmS59EieMO_Kq_SK3GLFEX2w"

# Start command function
def start(update, context):
    update.message.reply_text("🚀 Sniper Signal Bot is now active!")

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()